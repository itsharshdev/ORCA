import type { MeResponse } from '@/types/contract';

const getApiBaseUrl = (): string => {
  if (typeof window !== 'undefined' && window.location.hostname === 'localhost') {
    return import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1';
  }
  return import.meta.env.VITE_API_BASE_URL || '/api/v1';
};

export const authService = {
  /**
   * Fetches current authenticated user profile, active vessel, and permissions from /me.
   */
  async fetchMe(token?: string): Promise<MeResponse> {
    const baseUrl = getApiBaseUrl();
    const url = `${baseUrl}/me`;

    const headers: Record<string, string> = {
      Accept: 'application/json',
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(url, { headers });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: Failed to fetch current user session.`);
    }

    return (await response.json()) as MeResponse;
  },
};
