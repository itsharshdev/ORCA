import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Anchor, 
  ArrowRight, 
  ShieldCheck, 
  Sparkles, 
  Fish, 
  Cpu
} from 'lucide-react';
import { ROUTES } from '@/routes';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#F5F9FC] text-[#102B40] flex flex-col justify-between selection:bg-[#E8F4FA]">
      {/* Top Landing Navbar */}
      <header className="h-16 border-b border-[#D8E5EC] bg-white px-4 sm:px-8 flex items-center justify-between shadow-xs sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#E8F4FA] border border-[#CFE6F3] flex items-center justify-center text-[#147FB3] shadow-xs">
            <Anchor className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="font-display-decision font-black text-lg tracking-tight text-[#123B5D]">
              ORCA
            </span>
            <span className="text-[9px] font-semibold text-[#587083] uppercase tracking-wider">
              Smart India Hackathon 2026 • PS26176
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to={ROUTES.ABOUT}
            className="text-xs font-semibold text-[#587083] hover:text-[#123B5D] px-2 py-1 transition hidden sm:inline"
          >
            About System
          </Link>
          <Link
            to={ROUTES.CONTACT}
            className="text-xs font-semibold text-[#587083] hover:text-[#123B5D] px-2 py-1 transition hidden sm:inline"
          >
            Institutional Contact
          </Link>
          <Link
            to={ROUTES.LOGIN}
            className="px-4 py-2 rounded-xl bg-[#147FB3] hover:bg-[#0284C7] text-white font-bold text-xs font-label-caps tracking-wider transition shadow-xs flex items-center gap-1.5"
          >
            <span>LAUNCH CONSOLE</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-12 sm:py-20 text-center max-w-5xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-[#147FB3] text-xs font-bold font-label-caps mb-6 shadow-xs">
          <Sparkles className="w-3.5 h-3.5" />
          <span>MARINE ECOSYSTEM REASONING WITH COLLABORATIVE AGENTS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-[#123B5D] tracking-tight font-display-decision leading-tight mb-6">
          Deterministic Marine Safety &amp; Pelagic Intelligence
        </h1>

        <p className="text-sm sm:text-lg text-[#587083] max-w-2xl mx-auto leading-relaxed mb-8">
          ORCA correlates official INCOIS oceanography, IMD coastal weather warnings, and PostGIS maritime boundaries to deliver zero-hallucination operational voyage decisions.
        </p>

        {/* Primary Call to Action */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full max-w-md">
          <button
            type="button"
            onClick={() => navigate(ROUTES.DASHBOARD)}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#147FB3] hover:bg-[#0284C7] text-white font-bold text-sm font-label-caps tracking-wider transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
          >
            <span>ENTER FISHERMAN DASHBOARD</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => navigate(ROUTES.ASK)}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white border border-[#CBD5E1] hover:border-[#147FB3] text-[#123B5D] font-bold text-sm font-label-caps tracking-wider transition flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#147FB3]" />
            <span>ASK ORCA A QUERY</span>
          </button>
        </div>

        {/* 3 Core Architecture Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-16 text-left w-full">
          <div className="p-5 rounded-2xl bg-white border border-[#D8E5EC] shadow-sm flex flex-col gap-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-[#2E9B73] flex items-center justify-center mb-1">
              <Fish className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#123B5D]">PFZ = Opportunity</h3>
            <p className="text-xs text-[#587083] leading-relaxed">
              Live INCOIS GeoServer WFS integration extracts satellite thermal and chlorophyll fronts to detect high-yield harvest zones.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-[#D8E5EC] shadow-sm flex flex-col gap-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 text-[#147FB3] flex items-center justify-center mb-1">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#123B5D]">Deterministic Safety</h3>
            <p className="text-xs text-[#587083] leading-relaxed">
              PostGIS spatial geofencing enforces mandatory buffers around Naval defence zones, MPAs, and severe marine squall advisories.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-[#D8E5EC] shadow-sm flex flex-col gap-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-[#D99520] flex items-center justify-center mb-1">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#123B5D]">Explainable AI Engine</h3>
            <p className="text-xs text-[#587083] leading-relaxed">
              Every GO, CAUTION, and AVOID verdict carries an authoritative audit trail with data provenance timestamps and rule justifications.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="p-6 border-t border-[#D8E5EC] bg-white text-center text-xs text-[#587083] flex flex-col sm:flex-row items-center justify-between gap-3 px-4 sm:px-8">
        <div>
          &copy; 2026 ORCA Marine Decision Intelligence • Ministry of Earth Sciences / INCOIS Prototype
        </div>
        <div className="flex items-center gap-4 text-xs font-medium text-[#147FB3]">
          <Link to={ROUTES.DASHBOARD} className="hover:underline">Fisherman</Link>
          <Link to={ROUTES.AUTHORITY} className="hover:underline">Authority</Link>
          <Link to={ROUTES.DISASTER} className="hover:underline">Disaster</Link>
          <Link to={ROUTES.RESEARCH} className="hover:underline">Research</Link>
          <Link to={ROUTES.OPERATOR} className="hover:underline">Operator</Link>
        </div>
      </footer>
    </div>
  );
};
