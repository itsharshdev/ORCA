import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  Send, 
  CheckCircle2, 
  Clock, 
  Sliders, 
  Compass, 
  RefreshCw,
  Info
} from 'lucide-react';
import { useRegion } from '@/hooks/useRegion';
import { useOrchestration } from '@/hooks/useOrchestration';
import { DecisionHeroCard } from '@/components/decision/DecisionHeroCard';
import { ROUTES } from '@/routes';
import type { DecisionVerdict } from '@/types/marine';

export const AskOrcaPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { activeRegion } = useRegion();
  const { orchestration, runOrchestration, isOrchestrating } = useOrchestration();

  const queryParam = searchParams.get('q');
  const [queryInput, setQueryInput] = useState(queryParam || 'Can I go fishing tomorrow morning for five hours?');
  const [departureTime, setDepartureTime] = useState('05:45');
  const [durationHours, setDurationHours] = useState(5);

  const sampleQueries = [
    'Can I go fishing tomorrow morning for five hours?',
    'Is it safe to transit to Alibaug Outer Bank (PFZ-MUM-01)?',
    'What is the wave swell forecast for afternoon return?',
    'Evaluate patrol corridor clearance near Naval Anchorage',
  ];

  const handleRunQuery = async (queryTextToRun: string, duration?: number, departure?: string) => {
    if (!queryTextToRun.trim()) return;
    await runOrchestration(
      queryTextToRun,
      activeRegion.id,
      duration || durationHours,
      departure || `${departureTime} IST`
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleRunQuery(queryInput);
  };

  const handleWhatIfChange = (newDuration: number, newDeparture: string) => {
    setDurationHours(newDuration);
    setDepartureTime(newDeparture);
    handleRunQuery(
      `What-if scenario: Mission duration ${newDuration}h departing at ${newDeparture}`,
      newDuration,
      `${newDeparture} IST`
    );
  };

  const decision = orchestration?.decision;
  const simulatedVerdict: DecisionVerdict = decision?.verdict || 'CAUTION';

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 flex flex-col gap-6 select-none animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#D8E5EC]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-label-caps px-2.5 py-0.5 rounded bg-blue-50 text-[#147FB3] font-bold border border-[#CFE6F3]">
              ORCA CORE ENGINE
            </span>
            <span className="text-xs text-[#587083] font-telemetry">SECTOR: {activeRegion.name.toUpperCase()}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#123B5D] tracking-tight font-display-decision flex items-center gap-2.5">
            <Sparkles className="w-7 h-7 text-[#147FB3]" />
            Ask ORCA Marine Reasoning
          </h1>
          <p className="text-xs sm:text-sm text-[#587083]">
            Ask natural-language marine questions or configure mission parameters to correlate multi-agency forecasts with deterministic safety rules.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate(ROUTES.DASHBOARD)}
          className="px-3.5 py-2 rounded-xl bg-white border border-[#CBD5E1] hover:border-[#147FB3] text-xs font-bold text-[#123B5D] font-label-caps transition shadow-xs self-start sm:self-auto cursor-pointer"
        >
          &larr; BACK TO HOME
        </button>
      </div>

      {/* Query Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#D8E5EC] shadow-sm flex flex-col gap-3">
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-3">
          <div className="flex-1 flex items-center gap-3 px-3.5 py-2 bg-[#F5F9FC] border border-[#D8E5EC] rounded-xl w-full focus-within:border-[#147FB3] focus-within:bg-white transition">
            <Sparkles className="w-5 h-5 text-[#147FB3] shrink-0" />
            <input
              type="text"
              value={queryInput}
              onChange={(e) => setQueryInput(e.target.value)}
              placeholder="Ask anything: 'Can I go fishing tomorrow morning for 5 hours?'"
              className="w-full text-xs sm:text-sm text-[#123B5D] placeholder-[#7E93A3] focus:outline-none font-medium bg-transparent"
            />
          </div>

          <button
            type="submit"
            disabled={isOrchestrating}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#147FB3] hover:bg-[#0284C7] text-white font-bold text-xs font-label-caps tracking-wider transition flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-xs disabled:opacity-50"
          >
            {isOrchestrating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>CORRELATING...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>EVALUATE</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Sample Queries */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[11px] font-bold text-[#587083] font-label-caps">QUICK QUERIES:</span>
          {sampleQueries.map((sq, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setQueryInput(sq);
                handleRunQuery(sq);
              }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-[#F5F9FC] hover:bg-[#E8F4FA] text-[#123B5D] border border-[#D8E5EC] hover:border-[#147FB3] transition cursor-pointer font-medium"
            >
              {sq}
            </button>
          ))}
        </div>
      </div>

      {/* Multi-Agent Reasoning Execution Trace Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#D8E5EC] shadow-sm flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-[#EDF5F8] pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h3 className="text-xs font-bold text-[#123B5D] uppercase font-label-caps tracking-wider">
              MULTI-AGENT CORRELATION STREAM
            </h3>
          </div>
          <span className="text-[11px] font-telemetry text-[#587083]">
            {orchestration?.executionTimeMs || 420}ms reasoning latency
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
          {[
            {
              id: 'planner',
              name: '1. Mission Planner',
              desc: `${durationHours}h Trip (${departureTime} IST)`,
              status: 'COMPLETED',
            },
            {
              id: 'ocean',
              name: '2. Oceanography',
              desc: 'SST 27.8°C • Current 0.8 kts',
              status: 'COMPLETED',
            },
            {
              id: 'weather',
              name: '3. Meteorology',
              desc: 'Wind 12.5 kts • Wave 1.4m',
              status: 'COMPLETED',
            },
            {
              id: 'pfz',
              name: '4. PFZ / Fisheries',
              desc: 'Zone Alpha (18.5 km, 245°)',
              status: 'COMPLETED',
            },
            {
              id: 'geoSafety',
              name: '5. Deterministic GIS',
              desc: '4.2 km Buffer Clear',
              status: 'COMPLETED',
            },
          ].map((ag) => (
            <div
              key={ag.id}
              className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] flex flex-col justify-between gap-1"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#123B5D] font-label-caps">{ag.name}</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              </div>
              <div className="text-[11px] text-[#587083] font-medium leading-tight">{ag.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Primary Result: Decision Hero Card */}
      <DecisionHeroCard
        verdict={simulatedVerdict}
        confidence={decision?.confidenceScore || 78.4}
        departureTime={`${departureTime} IST`}
        durationHours={durationHours}
        vesselName="Matsya Sagar 1"
      />

      {/* Interactive What-If Scenario Re-evaluator */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-[#D8E5EC] shadow-sm flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#EDF5F8] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#E8F4FA] border border-[#CFE6F3] text-[#147FB3]">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#123B5D] tracking-tight font-display-decision uppercase">
                WHAT-IF MULTI-SCENARIO ENGINE
              </h3>
              <p className="text-[11px] text-[#587083]">
                Adjust departure and duration sliders to observe how the deterministic decision engine responds.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Departure Selector */}
          <div className="p-3.5 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-bold text-[#123B5D]">
              <span className="flex items-center gap-1.5 font-label-caps">
                <Clock className="w-3.5 h-3.5 text-[#147FB3]" />
                DEPARTURE TIME (IST)
              </span>
              <span className="font-telemetry text-[#147FB3]">{departureTime} IST</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {['05:45', '08:30', '13:00'].map((time) => (
                <button
                  key={time}
                  type="button"
                  onClick={() => handleWhatIfChange(durationHours, time)}
                  className={`py-2 rounded-lg text-xs font-bold font-telemetry transition border cursor-pointer ${
                    departureTime === time
                      ? 'bg-[#147FB3] text-white border-[#147FB3]'
                      : 'bg-white text-[#123B5D] border-[#CBD5E1] hover:bg-[#E8F4FA]'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>
          </div>

          {/* Duration Slider */}
          <div className="p-3.5 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-bold text-[#123B5D]">
              <span className="flex items-center gap-1.5 font-label-caps">
                <Compass className="w-3.5 h-3.5 text-[#147FB3]" />
                MISSION DURATION
              </span>
              <span className="font-telemetry text-[#147FB3] font-bold">{durationHours} HOURS</span>
            </div>
            <input
              type="range"
              min={2}
              max={12}
              step={1}
              value={durationHours}
              onChange={(e) => handleWhatIfChange(Number(e.target.value), departureTime)}
              className="w-full accent-[#147FB3] mt-2 cursor-pointer"
            />
            <div className="flex items-center justify-between text-[10px] text-[#7E93A3] font-telemetry">
              <span>2 hrs (Local)</span>
              <span>5 hrs (Standard)</span>
              <span>12 hrs (Deep Sea)</span>
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] text-xs text-[#587083] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-[#147FB3] shrink-0" />
            <span>
              {durationHours > 7 
                ? 'Extended voyage duration crosses midday wave swell limit (2.1m) triggering AVOID recommendation.'
                : 'Standard duration allows safe return to Sassoon Docks before midday chop.'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => navigate(ROUTES.MISSION)}
            className="px-3.5 py-1.5 rounded-lg bg-[#123B5D] hover:bg-[#0F2C4C] text-white font-bold text-xs font-label-caps tracking-wider transition shrink-0 cursor-pointer shadow-xs ml-3"
          >
            CONFIRM PLAN
          </button>
        </div>
      </div>
    </div>
  );
};
