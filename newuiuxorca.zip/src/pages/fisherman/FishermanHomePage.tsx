import React, { useState } from 'react';
import { DecisionHeroCard } from '@/components/decision/DecisionHeroCard';
import { TripSafetyHUD } from '@/components/safety/TripSafetyHUD';
import { PfzOpportunityPanel } from '@/components/fisheries/PfzOpportunityPanel';
import { PersistedObservationPanel } from '@/components/decision/PersistedObservationPanel';
import { AnalysisTraceAccordion } from '@/components/decision/AnalysisTraceAccordion';
import { useRegion } from '@/hooks/useRegion';
import { useOrchestration } from '@/hooks/useOrchestration';
import { 
  Waves, 
  Thermometer, 
  Navigation, 
  MapPin, 
  Calendar,
  Compass,
  ArrowRight,
  Sparkles,
  Search,
  Wind
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { ROUTES } from '@/routes';

export const FishermanHomePage: React.FC = () => {
  const { activeRegion } = useRegion();
  const { runOrchestration, isOrchestrating } = useOrchestration();
  const { weatherData, oceanData, vesselsData, pfzData } = activeRegion;
  const vessel = vesselsData.profiles[0];
  const topPfz = pfzData.zones[0];
  const navigate = useNavigate();

  const [promptText, setPromptText] = useState('Can I go fishing tomorrow morning for five hours?');

  const handleAskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptText.trim()) return;
    runOrchestration(promptText, activeRegion.id);
    navigate(`${ROUTES.ASK}?q=${encodeURIComponent(promptText)}`);
  };

  return (
    <div className="w-full max-w-7xl mx-auto p-4 sm:p-6 flex flex-col gap-6 select-none animate-fade-in">
      {/* Top Welcome & Region Status Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#D8E5EC]">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-telemetry text-[#147FB3] mb-1 font-bold">
            <MapPin className="w-3.5 h-3.5 text-[#147FB3]" />
            <span>{activeRegion.name.toUpperCase()} • {activeRegion.seaBody}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#123B5D] tracking-tight font-display-decision">
            Good morning, Captain
          </h1>
          <p className="text-xs sm:text-sm text-[#587083]">
            Active craft: <strong className="text-[#123B5D]">{vessel.name}</strong> • Home Port: {vessel.homePort.name}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to={ROUTES.MISSION}
            className="px-4 py-2.5 rounded-xl bg-[#147FB3] hover:bg-[#0284C7] text-white font-bold text-xs font-label-caps tracking-wider transition flex items-center gap-2 shadow-xs"
          >
            <Compass className="w-4 h-4" />
            <span>PLAN TRIP</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* 1. Ask ORCA Quick Prompt Bar */}
      <form 
        onSubmit={handleAskSubmit}
        className="w-full p-2 sm:p-2.5 rounded-2xl bg-white border border-[#D8E5EC] shadow-sm flex flex-col sm:flex-row items-center gap-2"
      >
        <div className="flex-1 flex items-center gap-2.5 px-3 py-1.5 w-full">
          <Sparkles className="w-5 h-5 text-[#147FB3] shrink-0" />
          <input
            type="text"
            value={promptText}
            onChange={(e) => setPromptText(e.target.value)}
            placeholder="Ask ORCA anything: 'Can I fish tomorrow morning for 5 hours?'"
            className="w-full text-xs sm:text-sm text-[#123B5D] placeholder-[#7E93A3] focus:outline-none font-medium"
          />
        </div>

        <button
          type="submit"
          disabled={isOrchestrating}
          className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#123B5D] hover:bg-[#0F2C4C] text-white font-bold text-xs font-label-caps tracking-wider transition flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-xs disabled:opacity-50"
        >
          {isOrchestrating ? (
            <span>REASONING...</span>
          ) : (
            <>
              <Search className="w-3.5 h-3.5" />
              <span>ASK ORCA</span>
            </>
          )}
        </button>
      </form>

      {/* 2. Primary Operational Decision Hero Card */}
      <DecisionHeroCard
        verdict="CAUTION"
        confidence={78.4}
        departureTime="05:45 IST"
        durationHours={5}
        vesselName={vessel.name}
      />

      {/* 3. Primary Instrument Cluster: Trip Safety & Opportunity Separation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Trip Safety HUD + Live Marine Conditions */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          <TripSafetyHUD
            vessel={vessel}
            nearestPfz={topPfz}
            departureTime="05:45 IST"
            durationHours={5}
          />

          {/* Quick Marine Conditions Summary Grid */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#D8E5EC] shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-[#EDF5F8] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#E8F4FA] border border-[#CFE6F3] text-[#147FB3]">
                  <Waves className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#123B5D] uppercase font-label-caps tracking-tight">
                    Marine Environmental Snapshot
                  </h3>
                  <span className="text-[11px] font-telemetry text-[#587083]">
                    Official INCOIS Ocean State Forecast
                  </span>
                </div>
              </div>
              <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-300 font-bold">
                ● LIVE FEED
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* Wave Swell */}
              <div className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] text-center">
                <div className="text-[10px] text-[#587083] uppercase font-bold font-telemetry">Wave Swell (Hs)</div>
                <div className="text-lg font-bold text-[#123B5D] font-mono mt-0.5">
                  {weatherData.currentConditions.waveHeightMeters}m
                </div>
                <div className="text-[10px] text-[#2E9B73] font-bold">Safe (&le; 1.4m)</div>
              </div>

              {/* Surface Wind */}
              <div className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] text-center">
                <div className="text-[10px] text-[#587083] uppercase font-bold font-telemetry flex items-center justify-center gap-1">
                  <Wind className="w-3 h-3 text-[#4DB7D8]" />
                  Wind Velocity
                </div>
                <div className="text-lg font-bold text-[#123B5D] font-mono mt-0.5">
                  {weatherData.currentConditions.windSpeedKnots} kts
                </div>
                <div className="text-[10px] text-[#587083] font-medium">{weatherData.currentConditions.windDirection}</div>
              </div>

              {/* Sea Surface Temp */}
              <div className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] text-center">
                <div className="text-[10px] text-[#587083] uppercase font-bold font-telemetry flex items-center justify-center gap-1">
                  <Thermometer className="w-3 h-3 text-[#D99520]" />
                  SST
                </div>
                <div className="text-lg font-bold text-[#123B5D] font-mono mt-0.5">
                  {oceanData.parameters.seaSurfaceTemperatureCelsius}°C
                </div>
                <div className="text-[10px] text-[#2E9B73] font-semibold">Thermal Front OK</div>
              </div>

              {/* Surface Drift */}
              <div className="p-3 rounded-xl bg-[#F5F9FC] border border-[#D8E5EC] text-center">
                <div className="text-[10px] text-[#587083] uppercase font-bold font-telemetry flex items-center justify-center gap-1">
                  <Navigation className="w-3 h-3 text-[#147FB3]" />
                  Current
                </div>
                <div className="text-lg font-bold text-[#123B5D] font-mono mt-0.5">
                  {oceanData.parameters.surfaceCurrentKnots} kts
                </div>
                <div className="text-[10px] text-[#587083] font-medium">{oceanData.parameters.currentDirection}</div>
              </div>
            </div>

            <div className="text-xs text-[#587083] pt-2.5 border-t border-[#EDF5F8] flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-medium">
                <Calendar className="w-3.5 h-3.5 text-[#147FB3]" />
                Forecast window valid through 18:00 IST
              </span>
              <Link
                to={ROUTES.MAP}
                className="text-[#147FB3] hover:underline text-xs font-bold font-label-caps"
              >
                VIEW CARTOGRAPHY &rarr;
              </Link>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Live PFZ Opportunity + Persisted Observations */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          <PfzOpportunityPanel />
          <PersistedObservationPanel />
        </div>
      </div>

      {/* Technical Reasoning & Multi-Agent Analysis Trace (Accordion for Inspection) */}
      <AnalysisTraceAccordion />
    </div>
  );
};
